# argocd-ssh-known-hosts-cm.yaml example

An example of an argocd-ssh-known-hosts-cm.yaml file:

```yaml
{!docs/operator-manual/argocd-ssh-known-hosts-cm.yaml!}
```
