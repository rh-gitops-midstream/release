#!/usr/bin/env bash

cat << EOF
apiVersion: v1
kind: ConfigMap
metadata:
  name: test-cm
data:
  foo: bar
EOF
