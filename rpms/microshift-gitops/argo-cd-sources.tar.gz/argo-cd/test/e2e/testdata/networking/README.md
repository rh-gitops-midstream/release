Sample app which deploys application with networking resources. Useful for manual testing.
